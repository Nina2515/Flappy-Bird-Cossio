import BaseScene from './BaseScene';


class PlayScene extends BaseScene {
  constructor (sharedConfig){
    super("PlayScene")
    this.config = sharedConfig;

    this.bird = null;
    this.brick = null;
    this.isPaused = false;

   
    this.BrickHorizontalDistance = 0;
   
    this.flapVelocity = 300;

    this.score = 0;
    this.scoreText = '';

    this.currentDifficulty = 'easy';
    this.difficulties = {
      'easy': {
        BrickHorizontalDistanceRange: [300, 350],
        BrickVerticalDistanceRange: [150, 200]
      },
      'normal': {
        BrickHorizontalDistanceRange: [280, 330],
        BrickVerticalDistanceRange: [140, 190]
      },
      'hard': {
        BrickHorizontalDistanceRange: [250, 310],
        BrickVerticalDistanceRange: [50, 100]
      }
    }
  }

  

  

  create() {
    this.currentDifficulty = 'easy';
    super.create()
    this.createBird();
    this.createBrick();
    this.createColliders();
    this.createScore();
    this.createPause();
    this.createEventHandler();
    this.createMyButton();
    this.listenToEvents();
    
    this.anims.create({
      key: 'fly',
      frames: this.anims.generateFrameNumbers('bird', { start: 9, end: 15}),
      
      frameRate: 8,
     
      repeat: -1
    })


    this.bird.play('fly');
  }

  flap() {
    if (this.isPaused) { return; }
    this.bird.body.velocity.y = -this.flapVelocity;
  }



  createMyButton(){

    const Bottom = this.add.image(this.config.width/80, this.config.height/60,"sky").setScale(0.04);

    Bottom.on('pointerdown', this.changeScene,this);


  }

  changeScene(){
    this.scene.start('Scene')
  }

  update(){
    this.checkCollision();
    this.recycleBrick();

  }

  listenToEvents() {
    if (this.pauseEvent) { return; }

    this.pauseEvent = this.events.on('resume', () => {
      this.initialTime = 3;
      this.countDownText = this.add.text(...this.screenCenter, 'Fly in: ' + this.initialTime, this.fontOptions).setOrigin(0.5);
      this.timedEvent = this.time.addEvent({
        delay: 1000,
        callback: this.countDown,
        callbackScope: this,
        loop: true
      })
    })
  }

  countDown() {
    this.initialTime--;
    this.countDownText.setText('Fly in: ' + this.initialTime);
    if (this.initialTime <= 0) {
      this.isPaused = false;
      this.countDownText.setText('');
      this.physics.resume();
      this.timedEvent.remove();
    }
  }


  createPause() {
    this.isPaused = false;
    let float= 30.23;
    const pauseButton = this.add.image(this.config.width/float -10, this.config.height/float -10, 'pause')
    .setInteractive()
      .setScale(3)
      .setOrigin(1);

      pauseButton.on('pointerdown', () => {
        this.isPaused = true;
        this.physics.pause();
        this.scene.pause();
        this.scene.launch('PauseScene');
      })
  }


  createColliders() {
    this.physics.add.collider(this.bird, this.brick, this.gameOver, null, this);
    this.physics.add.collider(this.stars, this.brick);
    this.physics.add.collider(this.bombs, this.brick, this.gameOver, null , this);
  }


  checkGameStatus() {
    if (this.bird.getBounds().bottom >= this.config.height || this.bird.y <= 0) {
      this.gameOver();
    }

    this.checkGameStatus();
    this.recycleBrick();
  }

  createBG() {
    this.add.image(0, 0, 'sky').setOrigin(0);
  }

  createBird() {

    this.bird = this.physics.add.sprite(this.config.startPosition.x, this.config.startPosition.y, 'bird')
    .setFlipX(true)
    .setScale(3)
    .setOrigin(0);
    this.bird.setBodySize(this.bird.width, this.bird.height - 8);
    this.bird.body.gravity.y = 600;
    this.bird.setCollideWorldBounds(true);
  }

  createBrick() {
    this.brick = this.physics.add.group();

    for (let i = 0; i < BRICK_TO_RENDER; i++) {
      let upperBrick = this.brick.create(0,this.config.height*8/10,'brick').setOrigin(1,1).setImmovable(true);
      let lowerBrick = this.brick.create(0,this.config.height*8/10,'brick').setOrigin(0,1).setImmovable(true);

      this.placeBrick(upperBrick, lowerBrick)
    }

    this.brick.setVelocityY(200);
  }

  placeBrick(upperBrick, lowerBrick) {
    const difficulty = this.difficulties[this.currentDifficulty];
    const rightMostX = this.getRightMostPipe();
    const BrickVerticalDistance = Phaser.Math.Between(...difficulty.BrickVerticalDistanceRange);
    const BrickVerticalPosition = Phaser.Math.Between(0 + 20, this.config.height - 20 - BrickVerticalDistance);
    const BrickHorizontalDistance = Phaser.Math.Between(...difficulty.BrickHorizontalDistanceRange);


    upperBrick.x = rightMostX + BrickHorizontalDistance;
    upperBrick.y = BrickVerticalPosition;

    lowerBrick.x = rightMostX + BrickHorizontalDistance;
    lowerBrick.y = BrickVerticalPosition;
  }

  getRightMostBrick() {
    let RightMost = 0;

    this.brick.getChildren().forEach(function(brick) {
      RightMost= Math.max(brick.x, RightMost);
    })

    return RightMost;
  }

  recycleBrick() {
    const tempBrick = [];
    this.brick.getChildren().forEach(brick => {

      if (brick.y - brick.body.height > this.config.height) {

        tempBrick.push(brick);

        if (tempBrick.length === 2) {
          this.placeBrick(...brick);
          this.increaseScore();
          this.saveBestScore();
          this.increaseDifficulty();
        }
      }
    })
  }

  increaseDifficulty() {
    if (this.score === 1) {
      this.currentDifficulty = 'normal';
    }

    if (this.score === 3) {
      this.currentDifficulty = 'hard';
    }
  }

  createanims(){
    this.anims.create({
      key: 'turn',
      frames: [ { key: 'bird', frame: 4 } ],
      frameRate: 20
  });

  this.anims.create({
      key: 'right',
      frames: this.anims.generateFrameNumbers('bird', { start: 5, end: 8 }),
      frameRate: 10,
      repeat: -1
  });

  cursors = this.input.keyboard.createCursorKeys();

  
  star = this.physics.add.group({
      key: 'star',
      repeat: 11,
      setXY: { x: 12, y: 0, stepX: 70 }
  });

  star.children.iterate(function (child) {

      child.setBounceY(Phaser.Math.FloatBetween(0.4, 0.8));

  });

  bombs = this.physics.add.group();
  }

  collectStar (bird, star)
{
    star.disableBody(true, true);

    score += 10;
    scoreText.setText('Score: ' + score);

    if (star.countActive(true) === 0)
    {
       
        star.children.iterate(function (child) {

            child.enableBody(true, child.x, 0, true, true);

        });

        var x = (bird.x < 400) ? Phaser.Math.Between(400, 800) : Phaser.Math.Between(0, 400);

        var bomb = bombs.create(x, 16, 'bomb');
        bomb.setBounce(1);
        bomb.setCollideWorldBounds(true);
        bomb.setVelocity(Phaser.Math.Between(-200, 200), 20);
        bomb.allowGravity = false;

    }
}

  hitBomb (bird, bomb)
{
  
    this.physics.pause();

    bird.setTint(0xff0000);

   bird.anims.play('turn');

    gameOver = true;
}

  checkCollision(){

    if(this.bird.getBounds().bottom >= this.config.height || this.bird.y <=0){

      this.gameOver();
    } 

  }


}

export default PlayScene;



 