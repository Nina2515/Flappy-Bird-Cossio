import BaseScene from './BaseScene';


class PlayScene extends BaseScene {
  constructor (sharedConfig){

    super('PlayScene', config);
  }




  create() {
    super.create()
    this.createBird();
    this.createBrick();
    this.createColliders();
    this.createScore();
    this.createPause();
    this.createEventHandler();
    this.createMyButton();
   
  }


  createMyButton(){

    const Bottom = this.add.image(this.config.width/80, this.config.height/60,"sky").setScale(0.04);

    Bottom.on('pointerdown', this.changeScene,this);


  }

  changeScene(){
    this.scene.start('Scene')
  }

  update(){
    this.checkCollision();
    this.recycleBrick();

  }

  createPause() {
    let float= 30.23;
    const pauseButton = this.add.image(this.config.width/float -10, this.config.height/float -10, 'pause')
    .setInteractive()
      .setScale(3)
      .setOrigin(1);

      pauseButton.on('pointerdown', () => {
        this.physics.pause();
        this.scene.pause();
      })
  }


  createColliders() {
    this.physics.add.collider(this.bird, this.pipes, this.gameOver, null, this);
  }


  checkGameStatus() {
    if (this.bird.getBounds().bottom >= this.config.height || this.bird.y <= 0) {
      this.gameOver();
    }

    this.checkGameStatus();
    this.recycleBrick();
  }

  createBG() {
    this.add.image(0, 0, 'sky').setOrigin(0);
  }

  createBird() {

    this.bird = this.physics.add.sprite(this.config.startPosition[0], this.config.startPosition[1], 'bird').setOrigin(0).setScale(0.1); 
    this.bird.body.gravity.y = 600;
    this.bird.setCollideWorldBounds(true);
  }

  createBrick() {
    this.brick = this.physics.add.group();

    for (let i = 0; i < BRICK_TO_RENDER; i++) {
      let upperBrick = this.pipes.create(0,this.config.height*8/10,'brick').setOrigin(1,1).setImmovable(true);
      let lowerBrick = this.pipes.create(0,this.config.height*8/10,'brick').setOrigin(0,1).setImmovable(true);

      this.placeBrick(upperBrick, lowerBrick)
    }

    this.brick.setVelocityY(200);
  }

  placeBrick(upperBrick, lowerBrick) {
    const BrickVerticalDistance = Phaser.Math.Between(...this.BrickVerticalDistanceRange);
    const BrickVerticalPosition = Phaser.Math.Between(20, this.config.height - 20 - BrickVerticalDistance);
    const BrickHorizontalDistance = Phaser.Math.Between(...this.BrickHorizontalDistanceRange);

    upperBrick.x = BrickVerticalPosition;
    upperBrick.y = this.getUpMostBrick() - BrickHorizontalDistance;

    lowerBrick.x = BrickVerticalPosition + BrickVerticalDistance;
    lowerBrick.y = upperBrick.y;
  }

  getUpMostBrick() {
    let UpMost = 0;

    this.brick.getChildren().forEach(function(brick) {
      UpMost= Math.min(brick.y, UpMost);
    })

    return UpMost;
  }

  recycleBrick() {
    const tempBrick = [];
    this.brick.getChildren().forEach(brick => {

      if (brick.y - brick.body.height > this.config.height) {

        tempBrick.push(brick);

        if (tempBrick.length === 2) {
          this.placeBrick(...brick);
        }
      }
    })
  }

  checkCollision(){

    if(this.bird.getBounds().bottom >= this.config.height || this.bird.y <=0){

      this.gameOver();
    } 

  }


}

export default PlayScene;



 